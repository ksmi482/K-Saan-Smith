/**
 * This program will compute various quantities
 * @K'Saan Smith
 * <pre>
 * Date: March 22, 2022
 * CSC 1253 Project #3 Section # 001<br>
 * Instructor: Dr. Duncan
 * File: AliquotGenerator.cpp
 * </pre>
 */

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
/**
* Computes the aliquot sum of the specified number
* @param num an integer
* @return the aliquot sum of the specified number
* if it is positive; otherwise, -1;
*/
long rStigma(long num);
{
    long rStigma =0;
    for (long i=1; i<=sqrt(num); i++)
    {
        if (num%i==0)
        {
            if(num/i == i)
            rStigma = rStigma + i;
            else
            {
            rStigma = rStigma + i;
            rStigma = rStigma +(num/i);
            }
        }
    }
}
    return sum;
}
    /**
    * Generates the string representation of a series whose terms
    * are increasing and consist of proper divisors of the specified number.
    * @param num an integer
    * @return a string representation of the series when num is
    * greater than 1, "0" when num is 1; otherwise "nan"
    */
 string genRSigSeries(long num)
 {
	 long num1 > 1;
	 string one > string(one);
	 long num0 = 1
			 string zero = string(one)
 }
 /**
 * Generates the aliquot sequence of a number and determines the
 * length of the sequence.
 * @param num an integer
 * @param sequence the aliquot sequence of the specified number when
 * num is positive; otherwise "nan".
 * @param length the length of the aliquot sequence of the specified
 * number when num is positive; otherwise 0
 */
 void aliquot(long num, string& sequence, long& length)
